



      BaKoMa Fonts for LyX-Win

      ==============================


      ANY DISTRIBUTION OF ONE OF THESE FONTS MUST INCLUDE THE LICENCE FILE
      THAT IS PART OF THIS PACKAGE

      The fonts included in this package are intended for Windows ports
      of Lyx, see http://www.lyx.org/download. The fonts are replacements
      that solve some display problems of math symbols.

      The fonts included in this package are taken from

      http://www.ctan.org/tex-archive/fonts/cm/ps-type1/bakoma/ttf/

      and have been modified for use with LyX. 
      The most recent versions of the original fonts are available 
      with the complete BaKoMa TeX distribution at

      http://www.ctan.org/tex-archive/systems/win32/bakoma/

      The author of these fonts, Basil K. Malyshev, has kindly
      granted permission to use and modify these fonts.
     
      The changes made are simple remappings of glyphs. These mappings
      are:

      cmsy10.ttf   char 8728 mapped to char 183 (\leq)
      cmsy10.ttf   char  196 mapped to char 127 (\spadesuit)
      msbm10.ttf   char 8728 mapped to char 183 (\nleqq)
      msbm10.ttf   char  196 mapped to char 127 (\backepsilon)
      cmmi10.ttf   char 8728 mapped to char 183 (\kapp)
      msam10.ttf   char  196 mapped to char 127 (\circleddash)
      msam10.ttf   char 8728 mapped to char 183 (\uparrows)
      
       
      The mappings do not change any glyph but make the glyphs mentioned 
      available under new codes, too. So the functionality of the fonts 
      will not be affected in any other application.


      In addition to the BaKoMa fonts, this font bundle contains the wasy font
      'wasy10.ttf' from the latex-xft font bundle:
      http://packages.qa.debian.org/l/latex-xft-fonts.html.
      The latex-xft bundle is published under the GPL.

      In addition to the BaKoMa fonts, this font bundle contains the esint font
      'esint10.ttf' from the esint package. It was converted from the type1
      version available at http://www.ctan.org/tex-archive/fonts/ps-type1/esint/.
      This PostScript Type 1 implementation of the font esint10, originally
      created by Eddie Saudrais using METAFONT, is freely available for general
      use.

      In addition to the BaKoMa fonts, this font bundle contains the stmary font
      'stmary10.ttf' from the stmaryrd package. It was converted from the type1
      version available at
      http://www.ctan.org/tex-archive/fonts/stmaryrd/ps-type1/hoekwater/.
      This PostScript Type 1 implementation of the font stmary10, originally
      created by Jeremy Gibbons and Alan Jeffrey using METAFONT, is in the
      public domain.


      Ekkehart Schlicht
      schlicht@lmu.de
      June 20, 2005.

